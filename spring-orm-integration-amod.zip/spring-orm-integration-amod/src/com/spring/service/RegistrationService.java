package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.RegistrationDAO;
import com.spring.dto.UserDTO;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationDAO registrationDAO;

	public boolean register(UserDTO userDTO) {
		Integer saveUSer = registrationDAO.saveUSer(userDTO);
		if (saveUSer != null && saveUSer > 0) {
			return true;
		} else {
			return false;
		}
	}

}
